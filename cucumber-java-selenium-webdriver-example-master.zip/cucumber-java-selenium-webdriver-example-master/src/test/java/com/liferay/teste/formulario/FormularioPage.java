package com.liferay.teste.formulario;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.liferay.teste.basepage.BasePage;

public class FormularioPage extends BasePage {
	private static final String LIFERAY_FORM_URL = "https://forms.liferay.com/web/forms/shared/-/form/122548";

	@FindBy(id = "_com_liferay_dynamic_data_mapping_form_web_portlet_DDMFormPortlet_kldx___menu")
	private WebElement botaoIdiomaAtual;

	@FindBy(xpath = "//*[@id=\"_com_liferay_dynamic_data_mapping_form_web_portlet_DDMFormPortlet_kldx___menu\"]/span[2]")
	private WebElement labelIdioma;

	@FindBy(xpath = "/html/body/div[4]/div/div/div/div/div/div/form/div[3]/div/div/div/div[1]/div/div/h4")
	private WebElement labelLetsPartyRock;

	@FindBy(className = "lfr-ddm-form-page-description")
	private List<WebElement> labelPageDescriptions;

	@FindBy(xpath = "//*[@id=\"_com_liferay_dynamic_data_mapping_form_web_portlet_DDMFormPortlet_kldx______menu__portugues_2d_brasil__1\"]")
	private WebElement linkOutroIdioma;

	@FindBy(xpath = "/html/body/div[1]/div/div/div/div/div/div/form/div[3]/div/div/div/div[1]/div/div/div[1]/div[1]/div/input")
	private WebElement inputNome;

	@FindBy(xpath = "/html/body/div[1]/div/div/div/div/div/div/form/div[3]/div/div/div/div[1]/div/div/div[1]/div[2]/div/div/div[1]/input[1]")
	private WebElement inputDataNascimento;

	@FindBy(xpath = "/html/body/div[1]/div/div/div/div/div/div/form/div[3]/div/div/div/div[1]/div/div/div[1]/div[2]/div/div/div[2]/div/div[1]/div/button[2]/svg/path[2]")
	private WebElement imgDataAtual;

	@FindBy(xpath = "/html/body/div[1]/div/div/div/div/div/div/form/div[3]/div/div/div/div[1]/div/div/div[2]/div/div/textarea")
	private WebElement inputResposta;

	@FindBy(xpath = "/html/body/div[1]/div/div/div/div/div/div/form/div[3]/div/div/div/div[2]/button")
	private WebElement botaoSubmeter;

	@FindBy(xpath = "/html/body/div[1]/div/div/div/div/div/div/form/div[3]/div/div/div/div[1]/div/div/div[1]/div[1]/div/div/div")
	private WebElement mensagemErroNome;

	@FindBy(xpath = "/html/body/div[1]/div/div/div/div/div/div/form/div[3]/div/div/div/div[1]/div/div/div[1]/div[2]/div/div[2]/div")
	private WebElement mensagemErroDataNascimento;

	@FindBy(xpath = "/html/body/div[1]/div/div/div/div/div/div/form/div[3]/div/div/div/div[1]/div/div/div[2]/div/div/div/div")
	private WebElement mensagemErroResposta;

	FormularioPage() {
		PageFactory.initElements(driver, this);
	}

	void abreFormulario() {
		driver.get(LIFERAY_FORM_URL);
		wait.forLoading(5);
	}

	public void isIdiomaSelecionado(String idioma) {
		wait.forElementToBeDisplayed(5, labelIdioma, "label idioma");
		assertTrue(this.labelIdioma.getText().equals(idioma));
	}

	public void alteraIdioma() {
		this.botaoIdiomaAtual.click();
		wait.forElementToBeDisplayed(5, linkOutroIdioma, "link de outro idioma");
		this.linkOutroIdioma.click();
	}

	public void isLabelPartyRockCorreto(String texto) {
		WebElement labelPageDescription = labelPageDescriptions.get(0);
		wait.forElementToBeDisplayed(5, labelPageDescription, "label descricao pagina");
		assertTrue(labelPageDescription.getText().contains(texto));
	}

	public void preenche(String nome, String dataNascimento, String motivo) {
		inputNome.sendKeys(nome);
		inputDataNascimento.sendKeys(Keys.HOME);
		inputDataNascimento.sendKeys(dataNascimento);
		inputResposta.sendKeys(motivo);
	}

	public void submete() {
		this.botaoSubmeter.click();
	}

	public void isMensagemExibidaTodosCampos(String mensagem) {
		wait.forElementToBeDisplayed(3, mensagemErroNome, "nome");
		assertTrue(mensagemErroNome.getText().contains(mensagem));
		wait.forElementToBeDisplayed(3, mensagemErroDataNascimento, "data de nascimento");
		assertTrue(mensagemErroDataNascimento.getText().contains(mensagem));
		wait.forElementToBeDisplayed(3, mensagemErroResposta, "resposta ");
		assertTrue(mensagemErroResposta.getText().contains(mensagem));
	}
}
