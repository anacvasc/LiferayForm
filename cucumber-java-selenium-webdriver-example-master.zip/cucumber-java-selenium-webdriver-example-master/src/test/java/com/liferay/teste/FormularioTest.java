package com.liferay.teste;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features = {"src/test/resources/com/liferay/teste/Formulario.feature"},
        strict = false, 
        glue = {"com.liferay.teste.infra.driver",
                "com.liferay.teste.formulario"},
        tags = "@implementado")

public class FormularioTest {

}
